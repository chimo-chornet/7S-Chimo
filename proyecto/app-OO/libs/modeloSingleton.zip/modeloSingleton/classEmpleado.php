<?php
require_once ('classModelo.php');

class empleado extends modelo
{
/**
 * En esta clase crearemos las consultas relacionadas con la tabla usuarios
 */
private $conexion;
public function __construct()
    {
        
        /*Los datos de la conexión los tomamos de config*/
        $this->conexion=parent::GetInstance();
      
    }
public function getEmpleado($empleado)
    {
      

            $consulta = "SELECT * FROM empleados WHERE id=:empleado";
            $result = $this->conexion->prepare($consulta);
            $result->bindParam(':empleado', $empleado);
            $result->execute();
            $resultado = $result->fetchAll(PDO::FETCH_ASSOC);
            return $resultado;
      
    }
}
?>
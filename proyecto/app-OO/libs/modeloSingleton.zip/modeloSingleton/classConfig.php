<?php
class Config {
	static public $hostname = "localhost";
	static public $nombre = "curso_php";
	static public $usuario = "root";
	static public $clave = "";
	
	/*En esta clase podemos además añadir por ejemplo rutas de imágenes, rutas css.
	 * En resumen constantes que se utilizarán en toda la aplicación.
	 * Podríamos hacerlo también con una biblioteca con constantes.
	 */
}
?>